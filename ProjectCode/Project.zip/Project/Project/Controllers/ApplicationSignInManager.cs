﻿namespace Project.Controllers
{
    internal class ApplicationSignInManager
    {
    }
}